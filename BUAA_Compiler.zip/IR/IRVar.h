#ifndef BUAA_COMPILER_IRVAR_H
#define BUAA_COMPILER_IRVAR_H

class MIRType {

};

class MVarIRType : public MIRType {

};

class MFuncIRType : public MIRType {

};

class MParamIRType : public MIRType {

};

class MIRVar {

};

class MTempIRVar : public MIRVar {

};

class MNamedIRVar : public MIRVar {

};

#endif //BUAA_COMPILER_IRVAR_H
